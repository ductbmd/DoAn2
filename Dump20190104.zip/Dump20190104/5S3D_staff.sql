-- MySQL dump 10.13  Distrib 5.7.24, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: 5S3D
-- ------------------------------------------------------
-- Server version	5.7.24-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) CHARACTER SET utf8 NOT NULL DEFAULT 'No name',
  `birth` date DEFAULT NULL,
  `sex` tinyint(4) NOT NULL DEFAULT '1',
  `CMND` varchar(45) DEFAULT '164635635',
  `SDT` varchar(45) DEFAULT '0912345678',
  `Email` varchar(45) DEFAULT 'example@ducmail.com',
  `id_department` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT '44',
  `position` int(11) DEFAULT '1' COMMENT '1-Nhân viên\n2-quản lý\n3-Phó phòng\n4-Trưởng phòng\n5-Phó giám đốc\n6-Giám đốc',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'To Ba Minh Duc','1999-08-14',1,'164635359','01633798800','minhduc98@gmail.com',1,45,6,'2018-12-11 05:13:55','2018-12-20 04:33:01'),(2,'Nguyễn văn Tám','1999-08-14',1,'164635358','01633798801','minhduc99@gmail.com',1,47,2,'2018-12-11 05:17:19','2018-12-24 08:39:46'),(3,'Nguyễn Chung','2018-12-12',1,'123456','014646744','chunghihi@gmail.com',1,44,3,'2018-12-11 21:16:40','2018-12-11 21:16:40'),(4,'demo giao diện mới','2018-12-17',1,'12345678','234567','chunghihi@gmail.com',1,44,1,'2018-12-16 10:12:13','2018-12-16 10:12:13'),(6,'To KU Da','2018-12-17',1,'1234567754','0123456789','tung@gmail.com',1,44,1,'2018-12-16 11:03:26','2018-12-16 11:03:26'),(7,'Nguyễn duy tùng','2018-12-20',1,'123456','01633798801','tung@gmail.com',1,44,1,'2018-12-19 11:35:44','2018-12-19 11:35:44'),(8,'Duy Tùng','2018-12-20',1,'1234567754','01633798801','duytung@gmail.com',1,43,1,'2018-12-19 11:38:30','2018-12-19 11:38:30'),(9,'Nguyễn Văn Quyết','1998-12-20',1,'12345678','0124875635','quyet@gmail.com',1,44,3,'2018-12-20 01:40:50','2018-12-20 01:40:50'),(10,'Phạm Uyên','2018-05-24',2,'12547856342','01678942234','puyen@gmail.com',1,49,5,'2018-12-24 08:47:46','2018-12-25 09:59:43'),(11,'Ngọc nam','2001-02-25',1,'164653347','00839847445','nam@gmail.com',NULL,48,4,'2018-12-25 09:09:14','2018-12-25 09:09:14'),(12,'Tình Đinh','1993-12-26',1,'0131234564','3534675868',NULL,1,50,1,'2018-12-25 10:19:23','2018-12-25 10:19:23'),(13,'Bích Hồng','1986-11-26',2,'1234567754','01633798801','hong@gmail.com',1,51,1,'2018-12-25 10:37:02','2018-12-25 10:37:02'),(14,'Mỹ Duyên','2001-12-16',2,'123456781','01633798803','my@gmail.com',1,52,1,'2018-12-25 10:38:38','2018-12-25 10:38:38'),(15,'Nguyễn  quang chung','1998-01-14',2,'137498321244','0145645784','nguyenquangchung@gmail.com',1,86,5,'2018-12-31 00:49:08','2018-12-31 00:49:29');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-04  1:07:55
