-- MySQL dump 10.13  Distrib 5.7.24, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: 5S3D
-- ------------------------------------------------------
-- Server version	5.7.24-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `url` text,
  `file_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '1: video, 2:audio 3:image',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  `updated_by` int(11) unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `staff_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` VALUES (4,'storage/photos/Screenshot from 2018-11-02 23-33-31.png','Screenshot from 2018-11-02 23-33-31.png','Demo',1,0,0,'2018-11-13 22:03:34','2018-11-13 22:03:34',NULL,0),(5,'storage/photos/[TontonHouse]-랫서판다의날_wall.jpg','[TontonHouse]-랫서판다의날_wall.jpg','Demo',1,0,0,'2018-11-13 22:48:08','2018-11-13 22:48:08',NULL,0),(6,'storage/photos/[TontonHouse]-랫서판다의날_wall.jpg','[TontonHouse]-랫서판다의날_wall.jpg','Demo',1,0,0,'2018-11-14 01:15:11','2018-11-14 01:15:11',NULL,0),(19,'storage/photos/bkav-bphone-2-thumb-300x300.jpg','bkav-bphone-2-thumb-300x300.jpg','Upload anh',3,0,0,'2018-12-16 03:12:34','2018-12-16 03:12:34',NULL,0),(23,'storage/photos/Screenshot from 2018-12-17 00-23-05.png','Screenshot from 2018-12-17 00-23-05.png','Upload anh',3,0,0,'2018-12-16 12:20:09','2018-12-16 12:20:09',NULL,0),(24,'storage/photos/Screenshot from 2018-12-17 00-23-05.png','Screenshot from 2018-12-17 00-23-05.png','Upload anh',3,0,0,'2018-12-16 12:36:20','2018-12-16 12:36:20',NULL,0),(25,'storage/photos/iphone5_white.jpg','iphone5_white.jpg','Upload anh',3,0,0,'2018-12-16 12:39:29','2018-12-16 12:39:29',NULL,0),(26,'storage/photos/bkav-bphone-2-thumb-300x300.jpg','bkav-bphone-2-thumb-300x300.jpg','Upload anh',3,0,0,'2018-12-17 09:57:29','2018-12-17 09:57:29',NULL,0),(27,'storage/photos/iphone5_white.jpg','iphone5_white.jpg','Upload anh',3,0,0,'2018-12-17 09:57:57','2018-12-17 09:57:57',NULL,0),(28,'storage/photos/xăng-thơm.png','xăng-thơm.png','Upload anh',3,0,0,'2018-12-18 10:30:09','2018-12-18 10:30:09',NULL,0),(29,'storage/photos/xăng-th.png','xăng-th.png','Upload anh',3,0,0,'2018-12-18 10:38:43','2018-12-18 10:38:43',NULL,0),(30,'storage/photos/vỉ-chân-ic.png','vỉ-chân-ic.png','Upload anh',3,0,0,'2018-12-18 10:39:17','2018-12-18 10:39:17',NULL,0),(31,'storage/photos/Panh.png','Panh.png','Upload anh',3,0,0,'2018-12-18 10:39:53','2018-12-18 10:39:53',NULL,0),(32,'storage/photos/nướcchì.png','nướcchì.png','Upload anh',3,0,0,'2018-12-18 10:40:23','2018-12-18 10:40:23',NULL,0),(33,'storage/photos/nhựa-thông.png','nhựa-thông.png','Upload anh',3,0,0,'2018-12-18 10:40:58','2018-12-18 10:40:58',NULL,0),(34,'storage/photos/nhíp.png','nhíp.png','Upload anh',3,0,0,'2018-12-18 10:41:23','2018-12-18 10:41:23',NULL,0),(35,'storage/photos/mohan.png','mohan.png','Upload anh',3,0,0,'2018-12-18 10:45:56','2018-12-18 10:45:56',NULL,0),(36,'storage/photos/maykhonhiet.jpg','maykhonhiet.jpg','Upload anh',3,0,0,'2018-12-18 10:46:43','2018-12-18 10:46:43',NULL,0),(37,'storage/photos/giadovimay.jpg','giadovimay.jpg','Upload anh',3,0,0,'2018-12-18 10:47:52','2018-12-18 10:47:52',NULL,0),(38,'storage/photos/Đồnghồđo.jpg','Đồnghồđo.jpg','Upload anh',3,0,0,'2018-12-18 10:48:27','2018-12-18 10:48:27',NULL,0),(39,'storage/photos/đèn-lúp.png','đèn-lúp.png','Upload anh',3,0,0,'2018-12-18 10:48:53','2018-12-18 10:48:53',NULL,0),(40,'storage/photos/đầu-đọc-thẻ.png','đầu-đọc-thẻ.png','Upload anh',3,0,0,'2018-12-18 10:49:46','2018-12-18 10:49:46',NULL,0),(41,'storage/photos/dao.png','dao.png','Upload anh',3,0,0,'2018-12-18 10:50:07','2018-12-18 10:50:07',NULL,0),(42,'storage/photos/tung.jpeg','tung.jpeg','Upload anh',3,0,0,'2018-12-19 11:35:44','2018-12-19 11:35:44',NULL,0),(43,'storage/photos/tung.jpeg','tung.jpeg','Upload anh',3,0,0,'2018-12-19 11:38:30','2018-12-19 11:38:30',NULL,0),(44,'storage/photos/avt.png','avt.png','Upload anh',3,0,0,'2018-12-20 01:40:50','2018-12-20 01:40:50',NULL,0),(45,'storage/photos/duc.jpg','duc.jpg','Upload anh',3,0,0,'2018-12-20 04:33:01','2018-12-20 04:33:01',NULL,0),(46,'storage/photos/ha.jpg','ha.jpg','Upload anh',3,0,0,'2018-12-20 04:35:31','2018-12-20 04:35:31',NULL,0),(47,'storage/photos/avt.png','avt.png','Upload anh',3,0,0,'2018-12-24 08:39:46','2018-12-24 08:39:46',NULL,0),(48,'storage/photos/zeyPq1x.png','zeyPq1x.png','Upload anh',3,0,0,'2018-12-25 09:09:14','2018-12-25 09:09:14',NULL,0),(49,'storage/photos/82437.jpg','82437.jpg','Upload anh',3,0,0,'2018-12-25 09:59:43','2018-12-25 09:59:43',NULL,0),(50,'storage/photos/nam.jpg','nam.jpg','Upload anh',3,0,0,'2018-12-25 10:19:23','2018-12-25 10:19:23',NULL,0),(51,'storage/photos/Grace-Chung_avatar_1463029662-400x400.jpg','Grace-Chung_avatar_1463029662-400x400.jpg','Upload anh',3,0,0,'2018-12-25 10:37:02','2018-12-25 10:37:02',NULL,0),(52,'storage/photos/avttk2-400x400.jpg','avttk2-400x400.jpg','Upload anh',3,0,0,'2018-12-25 10:38:38','2018-12-25 10:38:38',NULL,0),(53,'storage/photos/hack.jpg','hack.jpg','Upload anh',3,0,0,'2018-12-26 02:27:15','2018-12-26 02:27:15',NULL,0),(54,'storage/photos/hack.jpg','hack.jpg','Upload anh',3,0,0,'2018-12-26 02:31:40','2018-12-26 02:31:40',NULL,0),(55,'storage/photos/hack.jpg','hack.jpg','Upload anh',3,0,0,'2018-12-26 02:31:56','2018-12-26 02:31:56',NULL,0),(56,'storage/photos/bua-bon-tang-sang-tao-1.jpeg','bua-bon-tang-sang-tao-1.jpeg','Upload anh',3,0,0,'2018-12-28 06:26:51','2018-12-28 06:26:51',NULL,0),(73,'storage/photos/Modern-Clear-Console-Table.jpg','Modern-Clear-Console-Table.jpg','Upload anh',3,0,0,'2018-12-28 09:53:40','2018-12-28 09:53:40',NULL,0),(74,'storage/photos/Modern-Clear-Console-Table.jpg','Modern-Clear-Console-Table.jpg','Upload anh',3,0,0,'2018-12-28 09:54:53','2018-12-28 09:54:53',NULL,0),(75,'storage/photos/Modern-Clear-Console-Table.jpg','Modern-Clear-Console-Table.jpg','Upload anh',3,0,0,'2018-12-28 09:55:39','2018-12-28 09:55:39',NULL,0),(76,'storage/photos/Modern-Clear-Console-Table.jpg','Modern-Clear-Console-Table.jpg','Upload anh',3,0,0,'2018-12-28 09:55:57','2018-12-28 09:55:57',NULL,0),(77,'storage/photos/Modern-Clear-Console-Table.jpg','Modern-Clear-Console-Table.jpg','Upload anh',3,0,0,'2018-12-28 09:58:39','2018-12-28 09:58:39',NULL,0),(78,'storage/photos/Modern-Clear-Console-Table.jpg','Modern-Clear-Console-Table.jpg','Upload anh',3,0,0,'2018-12-28 10:00:09','2018-12-28 10:00:09',NULL,0),(79,'storage/photos/keo.png','keo.png','Upload anh',3,0,0,'2018-12-28 10:09:14','2018-12-28 10:09:14',NULL,0),(80,'storage/photos/keo.png','keo.png','Upload anh',3,0,0,'2018-12-28 10:09:48','2018-12-28 10:09:48',NULL,0),(81,'storage/photos/keo.png','keo.png','Upload anh',3,0,0,'2018-12-28 10:12:58','2018-12-28 10:12:58',NULL,0),(82,'storage/photos/img_5463.jpg','img_5463.jpg','Upload anh',3,0,0,'2018-12-28 10:14:05','2018-12-28 10:14:05',NULL,0),(83,'storage/photos/bua-bon-tang-sang-tao-1.jpeg','bua-bon-tang-sang-tao-1.jpeg','Upload anh',3,0,0,'2018-12-28 10:14:36','2018-12-28 10:14:36',NULL,0),(84,'storage/photos/ipxs.jpg','ipxs.jpg','Upload anh',3,0,0,'2018-12-30 21:16:35','2018-12-30 21:16:35',NULL,0),(85,'storage/photos/iphonexden.jpg','iphonexden.jpg','Upload anh',3,0,0,'2018-12-30 21:22:03','2018-12-30 21:22:03',NULL,0),(86,'storage/photos/images.jpeg','images.jpeg','Upload anh',3,0,0,'2018-12-31 00:49:08','2018-12-31 00:49:08',NULL,0),(87,'storage/photos/bua-bon-tang-sang-tao-1.jpeg','bua-bon-tang-sang-tao-1.jpeg','Upload anh',3,0,0,'2018-12-31 00:59:58','2018-12-31 00:59:58',NULL,0),(88,'storage/photos/keo.png','keo.png','Upload anh',3,0,0,'2018-12-31 01:01:36','2018-12-31 01:01:36',NULL,0),(89,'storage/photos/keo.png','keo.png','Upload anh',3,0,0,'2019-01-03 02:03:48','2019-01-03 02:03:48',NULL,0),(90,'storage/photos/bua-bon-tang-sang-tao-1.jpeg','bua-bon-tang-sang-tao-1.jpeg','Upload anh',3,0,0,'2019-01-03 09:49:25','2019-01-03 09:49:25',NULL,0),(91,'storage/photos/keo.png','keo.png','Upload anh',3,0,0,'2019-01-03 09:51:37','2019-01-03 09:51:37',NULL,0),(92,'storage/photos/keo.png','keo.png','Upload anh',3,0,0,'2019-01-03 09:55:20','2019-01-03 09:55:20',NULL,0),(93,'storage/photos/bua-bon-tang-sang-tao-1.jpeg','bua-bon-tang-sang-tao-1.jpeg','Upload anh',3,0,0,'2019-01-03 10:01:12','2019-01-03 10:01:12',NULL,0),(94,'storage/photos/keo.png','keo.png','Upload anh',3,0,0,'2019-01-03 10:19:14','2019-01-03 10:19:14',NULL,0);
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-04  1:07:54
