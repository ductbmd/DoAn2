-- MySQL dump 10.13  Distrib 5.7.24, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: 5S3D
-- ------------------------------------------------------
-- Server version	5.7.24-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post_do`
--

DROP TABLE IF EXISTS `post_do`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_do` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `localtion` varchar(45) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `description` varchar(200) CHARACTER SET utf8 DEFAULT 'Không đúng vị trí',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_do`
--

LOCK TABLES `post_do` WRITE;
/*!40000 ALTER TABLE `post_do` DISABLE KEYS */;
INSERT INTO `post_do` VALUES (1,200,'A3',1,55,'vứt lung tung','2018-12-26 02:31:56','2018-12-28 09:40:51','2018-12-28 09:40:51'),(2,202,'A2',2,56,'quá lung tung','2018-12-28 06:26:51','2018-12-28 06:26:51',NULL),(4,347,'G1',2,79,'vẫn là demo, đây chỉ là demo nên koong nên đọc đemo làm gì nhớ nhé','2018-12-28 10:09:14','2018-12-28 10:12:58','2018-12-28 10:12:58'),(5,348,'G1',12,82,'hihihihihihi','2018-12-28 10:14:05','2018-12-28 10:14:36','2018-12-28 10:14:36'),(6,1040,'O7',2,87,'Phòng bừa bãi','2018-12-31 00:59:58','2018-12-31 01:01:36','2018-12-31 01:01:36'),(7,644,'T9',2,89,'chụp ảnh năm mới','2019-01-03 02:03:48','2019-01-03 09:48:09','2019-01-03 09:48:09'),(8,998,'Y6',5,91,'năm mới','2019-01-03 09:51:37','2019-01-03 09:51:37',NULL),(9,645,'T4',5,92,'năm 2','2019-01-03 09:55:20','2019-01-03 10:01:12','2019-01-03 10:01:12'),(10,843,'Y9',12,94,'demo năm mới 3','2019-01-03 10:19:14','2019-01-03 10:19:14',NULL);
/*!40000 ALTER TABLE `post_do` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-04  1:07:54
